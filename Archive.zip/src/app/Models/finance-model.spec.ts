import { FinanceModel } from './finance-model';

describe('FinanceModel', () => {
  it('should create an instance', () => {
    expect(new FinanceModel()).toBeTruthy();
  });
});
