import { CommonModule } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { FianaceServiceService } from '../services/fianace-service.service';
import { LoginModel } from '../Models/finance-model';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, RouterModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginform!: FormGroup;
  submit = false;
  constructor(private fb: FormBuilder,
    private router: Router,
    private service :FianaceServiceService
  ) { 
    this.loginform = this.fb.group({
      email: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }
  get Controls(){
    return this.loginform.controls;
  }
  
  ngOnInit(): void {
  
  }
  onSubmit() {
    this.submit = true;
   let api = 'Login/CheckLogin'
   const model = new LoginModel();
   model.email = this.Controls['email'].value;
   model.password = this.Controls['password'].value;
   if(this.loginform.valid){
    this.service.create(api,model).subscribe((res:any)=>{
      if(res.isSuccess){
        alert("Login Successfully");
        this.loginform.reset();
      }
      else{
        alert("Wrong Email or Password");
      }
     })
   }
   else{
    alert("Enter The Field First")
   }
  

    
  }
  switchToRegister(): void {
    // this.router.navigate(['/register']);
  }
}

