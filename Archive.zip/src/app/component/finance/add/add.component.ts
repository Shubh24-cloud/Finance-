import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { IncomeModel } from '../../../Models/finance-model';
import { FianaceServiceService } from '../../../services/fianace-service.service';

@Component({
  selector: 'app-add',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  cashForm!: FormGroup;
  submitCash = false;
service = inject(FianaceServiceService);
  constructor(private fb: FormBuilder) {
    this.cashForm = this.fb.group({
      source: ['', Validators.required],
      amount: ['', [Validators.required, Validators.min(0)]],
      date: ['', Validators.required]
    });
  }
  get Controls(){
    return this.cashForm.controls;
  }

  ngOnInit(): void {
  
  }
  onSubmitCash() {
    this.submitCash = true;
    let api = 'Login/AddIncome'
    const model = new IncomeModel()
    model.amount = this.Controls['amount'].value;
    model.source = this.Controls['source'].value;
    model.date = this.Controls['date'].value;

    if (this.cashForm.valid) {
      this.service.create(api,model).subscribe((res:any)=>{
        if(res.isSuccess){
          alert("Cash Added SuccessFully");
          console.log(res);
        }
        else{
          alert("Error Occured");
        }
      })
    }
    else{
      alert("Please Entered All fields");
    }
  }
}
