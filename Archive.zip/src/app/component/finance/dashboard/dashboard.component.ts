import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { DxChartModule, DxPieChartModule } from 'devextreme-angular';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [DxChartModule, DxPieChartModule, CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  totalIncome: number = 1500000; 
  spentTillNow: number = 0; 
  remainingBudget: number = 0; 
  chartData: { month: string, spent: number, saved: number }[] = [];
  pieChartData = [
    { category: 'Daily Needs', amount: 10000 },
    { category: 'Lifestyle', amount: 8000 },
    { category: 'Health', amount: 4000 },
    { category: 'Other', amount: 2000 },
  ];
  ngOnInit(): void {
    this.calculateChartData();
  }
  calculateChartData(): void {
    const months = [
      'January', 'February', 'March', 'April', 'May', 'June',
      'July', 'August', 'September', 'October', 'November', 'December'
    ];

    const spentAmounts = [76000, 50000, 57000, 60000, 55000, 70000, 65000, 48000, 54000, 60000, 49000, 53000];
    const totalSpent = spentAmounts.reduce((sum, value) => sum + value, 0); 
    const monthlyIncome = this.totalIncome / months.length;
    
    this.chartData = months.map((month, index) => ({
      month,
      spent: spentAmounts[index],
      saved: monthlyIncome - spentAmounts[index]
    }));
    
    this.spentTillNow = totalSpent;
    this.remainingBudget = this.totalIncome - totalSpent;
  }

}
